/**
 * {@link org.postgresql.pljava.tasks.JarLoaderTask JarLoaderTask} is a task
 * for deploying a jar to a specified database
 * as part of an <a href='http://ant.apache.org/' target='_parent'>Ant</a>
 * build.
 */
package org.postgresql.pljava.tasks;
