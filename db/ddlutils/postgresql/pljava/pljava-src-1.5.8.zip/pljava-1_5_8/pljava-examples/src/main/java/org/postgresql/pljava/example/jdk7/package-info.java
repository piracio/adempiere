/**
 * Examples only built on Java 7 or later.
 * @author Chapman Flack
 */
package org.postgresql.pljava.example.jdk7;
