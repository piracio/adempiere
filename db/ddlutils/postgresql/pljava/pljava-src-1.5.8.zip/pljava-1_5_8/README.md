![PL/Java](https://raw.github.com/tada/pljava/gh-pages/images/pljava_logo.jpg)

PL/Java is a free add-on module that brings Java™ Stored Procedures, Triggers,
and Functions to the PostgreSQL™ backend.

More information about this project can be found in the [PL/Java Wiki][wiki]
and on the [project information site][pages].

[wiki]: https://github.com/tada/pljava/wiki
[pages]: https://tada.github.io/pljava/
